#include <stdio.h>
#include <stdlib.h>
#include "cc.h"
#include "vv.h"
#include "fonctionnel.h"
#include "extension.h"
#include "simu.h"
#include "anthropique.h"


void affichermenu(){
    printf("****************************************************\n");
    printf("*                  MENU PRINCIPAL                  *\n");
    printf("****************************************************\n");
    printf("* 1.  Liste des sommets                            *\n");
    printf("* 2.  La liste des arcs                            *\n");
    printf("* 3.  Successeurs et predecesseurs d'un sommet     *\n");
    printf("* 4.  Afficher les criteres de complexite          *\n");
    printf("* 5.  Verifier la connexite                        *\n");
    printf("* 6.  Evaluer la forte connextite                  *\n");
    printf("* 7.  Affichage de sommets particuliers            *\n");
    printf("* 8.  Chaine alimentaire d'une espece              *\n");
    printf("* 9.  Estimation de l'importance relative          *\n");
    printf("* 10. Simulation suppression d'une espece          *\n");
    printf("* 11. Simulation de l'evolution des populations    *\n");
    printf("* 12. Modifier l'evolution des populations         *\n");
    printf("* 13. Aspect anthropiques                          *\n");
    printf("* 14. Evolution temporelle de la population        *\n");
    printf("* 15. Charger un autre fichier                     *\n");
    printf("* 16. Reafficher le menu                           *\n");
    printf("* 17. Quitter                                      *\n");
    printf("****************************************************\n");
}

char fichier[100];

// Menu principal
void menuUtilisateur() {
    CFCData data;
    int choix,sommetiD;
    int tailleHistorique = 0;
    int sommetIdASupprimer;
    double* centralite = CentraliteIntermediaire();
    // Initialisation des structures
    Ecosysteme ecosysteme;
    EvolutionPopulation historique[100]; // Tableau pour enregistrer l'évolution


    do {
        printf("Choisir une option:");
        scanf("%d", &choix);


        switch (choix) {
            case 1:
                afficherSommets();
                afficherNombreSommets();
                break;
            case 2:
                afficherArcs();
                break;
            case 3:
                printf("Entrez le numero du sommet : ");
                scanf("%d", &sommetiD);
                if (!sommetExiste(sommetiD)) {
                    printf("Erreur : Le sommet avec l'ID %d n'existe pas.\n", sommetiD);
                    return;
                }
                afficherSuccesseurs(sommetiD);
                afficherPredecesseurs(sommetiD);
                break;
            case 4:
                afficherComplexite();
                break;
            case 5:
                gererComposantes(&data);
                break;
            case 6:
                analyserConnexite(&data);
                break;
            case 7:
                sommetsSourceUnique();
                derniersMaillons();
                premiersMaillons();
                break;
            case 8:
                afficherNiveauxTrophiques();
                break;
            case 9:
                AfficherCentraliteRadiale();
                AfficherCentraliteIntermediaire(centralite);
                break;

            case 10:
                printf("Entrez l'ID du sommet a supprimer : ");
                scanf("%d", &sommetIdASupprimer);

                simulationSuppressionSommet(sommetIdASupprimer);
                break;


            case 11:{}
            int etapes;
                // Saisie du nombre d'etapes de simulation avec validation
                while (1) {
                    printf("Entrez le nombre d'etapes de simulation : ");
                    if (scanf("%d", &etapes) == 1 && etapes > 0) {
                        break; // Entree valide
                    }
                    printf("Erreur : veuillez entrer un entier positif pour le nombre d'etapes.\n");

                    // Vider le tampon
                    while (getchar() != '\n');
                }

                // Demander si l'utilisateur souhaite modifier un sommet avec validation
                // Continuer avec la simulation
                printf("Lancement de la simulation pour %d etapes.\n", etapes);
                // Simuler les etapes (vous pouvez ajouter votre logique ici)
                simulerPopulations(etapes);
                const char *nomFichierTexte = "chart.txt";
                const char*nomFichierScript = "chart.plt";
                genererScriptGnuplot(nomFichierTexte, nomFichierScript);
                break;

            case 12:{}
                int reponse;
                while (1) {
                    printf("Souhaitez-vous changer la valeur d'un sommet avant la simulation ? (1 = Oui, 0 = Non) : ");
                    if (scanf("%d", &reponse) == 1 && (reponse == 1 || reponse == 0)) {
                        break; // Entree valide
                    }
                    printf("Erreur : veuillez entrer 1 pour Oui ou 0 pour Non.\n");
                    // Vider le tampon
                    while (getchar() != '\n');
                }
                if (reponse == 1) {
                    // Appeler la fonction pour modifier le sommet
                    modifierSommet();  // Cette fonction permet à l'utilisateur de modifier un sommet
                }

                break;
            case 13:
                appliquerImpactsAnthropiques(&ecosysteme, historique, &tailleHistorique, fichier);
                break;
            case 14:
                printf("\n=== Evolution de la population ===\n");
                if (strcmp(fichier, "123.txt") == 0) {
                    printf("Annee\tCrevettes\tPredateurs\tPecheurs\n");
                } else if (strcmp(fichier, "2.txt") == 0) {
                    printf("Annee\tRhinoceros\tPredateurs\tBraconniers\n");
                }
                afficherEvolution(historique, tailleHistorique);
                break;
            case 15:
                printf("Entrez le nom du fichier a charger : ");
                scanf("%s", fichier);
                initialiser(&data);
                if (!chargerGraphe(fichier)) {
                    printf("Erreur lors du chargement du fichier.\n");
                } else {
                    printf("Nouveau fichier charge \n");
                }
                break;
            case 16:
                affichermenu();
                break;
            case 17:
                printf("Au revoir !\n");
                break;
            default:
                printf("Choix invalide.\n");
        }
    } while (choix != 16);
}

int main() {
    CFCData data;
    int tailleHistorique = 0;
    // Initialisation des structures
    Ecosysteme ecosysteme;
    EvolutionPopulation historique[100]; // Tableau pour enregistrer l'évolution
    printf("Entrez le nom du fichier: \n");
    scanf("%s", fichier);
    //rajouter erreur

    affichermenu();

    initialiser(&data);
    if (!chargerGraphe(fichier)) {
        printf("Erreur lors du chargement du graphe.\n");
        return EXIT_FAILURE;
    }

    // Initialisation explicite du tableau historique
    for (int i = 0; i < 100; i++) {
        historique[i].annee = 0;
        historique[i].populationCrevettes = 0;
        historique[i].populationPredateurs = 0;
        historique[i].nombrePecheurs = 0;
    }

    // Initialisation des données de base pour l'année 0
    historique[0].annee = 0;
    historique[0].populationCrevettes = 50;  // Population initiale de crevettes (en milliers)
    historique[0].populationPredateurs = 10; // Population initiale de prédateurs (en milliers)
    historique[0].nombrePecheurs = 0;        // Nombre initial de pêcheurs (en milliers)
    tailleHistorique++;                      // L'année 0 est maintenant enregistrée

    // Initialisation des autres variables
    initialiserEcosysteme(&ecosysteme);

    menuUtilisateur();
    return 0;
}


