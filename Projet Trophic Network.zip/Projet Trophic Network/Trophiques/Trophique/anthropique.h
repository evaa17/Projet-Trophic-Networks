//
// Created by marti on 08/12/2024.
//

#ifndef UNTITLED9_ANTHROPIQUE_H
#define UNTITLED9_ANTHROPIQUE_H

#include <stdio.h>
#include <stdlib.h>

// Définition d'une structure pour enregistrer l'évolution des populations par an
typedef struct {
    int annee;
    int populationCrevettes;
    int populationPredateurs;
    int nombrePecheurs;
} EvolutionPopulation;

// Définition de la structure pour gérer les données de l'écosystème
typedef struct {
    int populationCrevettes;
    int populationPredateurs;
    double tauxCroissanceCrevettes;
    double tauxCroissancePredateurs;
    int capaciteChargeCrevettes;
    int capaciteChargePredateurs;
} Ecosysteme;

// Déclaration des fonctions
void initialiserEcosysteme(Ecosysteme *ecosysteme);
void MiseaJour_Pop(Ecosysteme *ecosysteme, int nombrePecheurs, EvolutionPopulation *historique, int tailleHistorique);
void mettreAJourBraconnage(Ecosysteme *ecosysteme, int nombreBraconniers, EvolutionPopulation *historique, int tailleHistorique);
void afficherEvolution(EvolutionPopulation *historique, int tailleHistorique);
void ajusterPopulationRecursivement(int sommetId, double facteurAjustement);
void appliquerImpactsAnthropiques(Ecosysteme *ecosysteme, EvolutionPopulation *historique, int *tailleHistorique, const char *fichierCharge);

#endif //UNTITLED9_ANTHROPIQUE_H
