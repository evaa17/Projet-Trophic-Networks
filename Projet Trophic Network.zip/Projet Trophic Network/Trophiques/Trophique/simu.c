//
// Created by marti on 08/12/2024.
//

#include "simu.h"
#include "cc.h"
#include "vv.h"

bool sommetEstEssentiel(int sommetId) {
    int degreEntree = 0, degreSortie = 0;
    // Appel de la fonction CentraliteRadiale pour récupérer la centralité et les degrés
    double centralite = CentraliteRadiale(sommetId, &degreEntree, &degreSortie);

    // Déterminer si le sommet est essentiel
    return (centralite > 0.5);  // Seuil arbitraire pour définir si un sommet est essentiel
}


// Fonction pour vérifier si un sommet peut être remplacé
bool sommetPeutEtreRemplace(int sommetId) {
    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet1 == sommetId || arcs[i].sommet2 == sommetId) {
            if (arcs[i].coefficient < 0.4) {
                return true;  // Si le coefficient alimentaire est faible, il peut être remplacé
            }
        }
    }
    return false;
}
// Vérifie si un sommet a des successeurs
bool aDesSuccesseurs(int sommetId) {
    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet2 == sommetId) {
            return true; // Il existe au moins un successeur
        }
    }
    return false; // Aucun successeur trouvé
}

// affichage des successeurs et predecesseurs pas bon mais le reste foncitonne bien
// Fonction de simulation de la suppression d'un sommet

void simulationSuppressionSommet(int sommetId) {
    double* centraliteInter = CentraliteIntermediaire();
    // Accéder à la centralité du sommet spécifié
    double centraliteSommet = centraliteInter[sommetId];
    if (!sommetExiste(sommetId)) {
        printf("Erreur : Le sommet avec l'ID %d n'existe pas.\n", sommetId);
        return;
    }

    // Sauvegarder l'etat initial des arcs
    Arc sauvegardeArcs[nombreArcs];
    memcpy(sauvegardeArcs, arcs, nombreArcs * sizeof(Arc));

    // Sauvegarder l'etat initial des sommets
    Sommet sauvegardeSommets[nombreSommets];
    memcpy(sauvegardeSommets, sommets, nombreSommets * sizeof(Sommet));


    // Affichage du début de la simulation
    printf("\n                                                    SIMULATION DE LA SUPPRESSION D'UNE ESPECE %d (%s):\n", sommetId, sommets[sommetId - 1].nom);
    printf("                                      ---------------------------------------------------------------------------\n");
    printf("\n                                               *******Etude base sur la mesure de centralite radiale********\n");

    // Vérification si le sommet est essentiel pour l'écosystème
    if (sommetEstEssentiel(sommetId)) {
        printf("\n-Ce sommet a une centralite radiale elevee, est  donc essentiel pour l'ecosysteme.\n");

        // Vérification si le sommet peut être remplacé
        if (sommetPeutEtreRemplace(sommetId)) {
            printf("Il peut etre remplace car il n'est pas indispensable a l'alimentation de ces predateurs.\n");
            // Vérification des successeurs
            if (aDesSuccesseurs(sommetId)) {
                printf("\n-Les successeurs du sommet %d (%s) ont d'autres sources d'alimentation :\n", sommetId, sommets[sommetId - 1].nom);
                for (int i = 0; i < nombreArcs; i++) {
                    if (arcs[i].sommet1 == sommetId) { // Trouver les successeurs
                        int successeur = arcs[i].sommet2;
                        printf("Sommet %d (%s) -> Sommet %d (%s) avec poids %.2f\n",
                               sommetId, sommets[sommetId - 1].nom,
                               successeur, sommets[successeur - 1].nom, arcs[i].coefficient);
                    }
                }
                printf("-Neanmoins, la suppression de %s affecte quand meme la survie de ces especes.\n", sommets[sommetId - 1].nom);
            } else {
                printf("\n-Le sommet %d (%s) est un dernier maillon et n'a pas de successeurs.\n", sommetId, sommets[sommetId - 1].nom);
            }

        } else {
            printf("\n-La suppression de ce sommet entrainerait des repercussions graves.\n");
            printf("-%s est essentiel pour l'alimentation de certaines especes et sa perte pourrait entrainer une reduction importante de leur population.\n", sommets[sommetId - 1].nom);
        }
    } else {
        printf("\n-Le sommet a une centralite radiale faible et sa suppression n'aura probablement pas d'impact majeur.\n");
    }

    // Affichage des prédécesseurs
    printf("\nPar contre, ces predecesseurs : \n");
    bool premier = true;
    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet1 == sommetId) {
            if (!premier) {
                printf(", ");
            }
            printf("Sommet %d (%s)", arcs[i].sommet2, sommets[arcs[i].sommet2 - 1].nom);
            premier = false;
        }
    }
    printf(" ont moins de predateurs, ce qui entrainera probablement une augmentation de leur population.\n");
    printf("\n\n                                               *******Etude base sur la mesure d'intermediarite*******\n");


    // Analyse basée sur la centralité intermédiaire
    if (centraliteSommet > 0.5) {
        printf("\n- Centralite intermediaire elevee : Ce sommet joue un role de connexion important dans le reseau.\n");

        // Suppression du sommet : éliminer les arcs connectés à ce sommet
        for (int i = 0; i < nombreArcs; i++) {
            if (arcs[i].sommet1 == sommetId || arcs[i].sommet2 == sommetId) {
                arcs[i].sommet1 = -1;
                arcs[i].sommet2 = -1;
            }
        }

        // Vérification des sommets restants qui sont isolés
        bool casIsolesTrouves = false;
        for (int i = 1; i <= nombreSommets; i++) {
            if (i != sommetId) {
                bool sommetIsole = true;
                for (int j = 0; j < nombreArcs; j++) {
                    if ((arcs[j].sommet1 == i && arcs[j].sommet2 != -1) ||
                        (arcs[j].sommet2 == i && arcs[j].sommet1 != -1)) {
                        sommetIsole = false;
                        break;
                    }
                }

                if (sommetIsole) {
                    printf("\n- Attention : Le sommet %d devient isole après la suppression de %d.\n", i, sommetId);
                    casIsolesTrouves = true;
                }
            }
        }

        if (!casIsolesTrouves) {
            printf("-Aucun sommet isole trouve apres la suppression, le reseau n'est pas fragmente a cause de cette suppression.\n");
        }
    } else {
        printf("\n- Centralite intermediaire faible : Ce sommet a un role mineur dans la connectivite globale du reseau.\n");

        // Vérification si c'est un producteur primaire
        if (sommets[sommetId - 1].niveauTrophique == 0) {
            printf("- Cependant, etant un producteur primaire, sa suppression fragilise le reseau.\n");
        }
    }

    printf("                                      ---------------------------------------------------------------------------\n");
    // Restaurer l'etat initial
    memcpy(arcs, sauvegardeArcs, nombreArcs * sizeof(Arc));
    memcpy(sommets, sauvegardeSommets, nombreSommets * sizeof(Sommet));

    printf("\nSimulation terminee, l'etat initial a ete restaure\n");
}

