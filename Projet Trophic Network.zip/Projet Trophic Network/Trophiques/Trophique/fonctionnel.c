#include "fonctionnel.h"
#include <stdio.h>
#include <math.h>
// Pour round() et autres fonctions mathematiques
#include "extension.h"
#include <unistd.h>

#define CONSOMMATION_MAX 1000000  // Consommation maximale

// Calculer la capacite de charge (K) d'un sommet
int calculerCapaciteCharge(int sommetId) {
    int K = 0;  // Initialisation de K

    if (sommetId <= 0 || sommetId > nombreSommets) {
        printf("Erreur: sommetId %d invalide.\n", sommetId);
        return sommets[sommetId - 1].population; // Retourner la population actuelle
    }

    // Calculer K selon les arcs de predation
    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet1 == sommetId) {  // Si predateur
            int proieId = arcs[i].sommet2;
            if (proieId > 0 && proieId <= nombreSommets) {
                double consommation = arcs[i].coefficient;
                double populationProie = sommets[proieId - 1].population;
                K += (int)round(consommation * populationProie);  // Arrondi
            }
        }
    }

    // Si K est 0, ajuster selon type d'espece
    if (K == 0) {
        if (sommets[sommetId - 1].niveauTrophique == 0) {
            K = (int) round(sommets[sommetId - 1].population * 2);
        } else {
            K = (int) round(sommets[sommetId - 1].population * 3);
        }
    }
    // Si K < 50% de la population, ajuster
    if (K < sommets[sommetId - 1].population * 0.5) {
        K = (int)sommets[sommetId - 1].population;
    }
    return K;
}


// Calculer la consommation totale d'un sommet
double calculerQuantiteConsommee(int sommetId) {
    double consommationTotale = 0.0;

    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet2 == sommetId) {  // Si espece est une proie
            int predateurId = arcs[i].sommet1;
            double consommation = arcs[i].coefficient * sommets[predateurId - 1].population;
            consommation = (consommation > CONSOMMATION_MAX) ? CONSOMMATION_MAX : consommation;
            consommationTotale += consommation;
        }
    }

    return consommationTotale;
}

void mettreAJourPopulations() {
    int nouvellesPopulations[MAX_SOMMETS];  // Tableau pour stocker les nouvelles populations

    for (int i = 0; i < nombreSommets; i++) {
        int N = (int) sommets[i].population;
        double r = sommets[i].tauxCroissance;
        int K = calculerCapaciteCharge(sommets[i].id);
        int consommation = (int) calculerQuantiteConsommee(sommets[i].id);
        if (K == 0){
            K = 10000;
        }
        // Calcul de la croissance et de la nouvelle population
        double croissance = r * N * (1 - (double) N / K);
        double nouvellePopulationCalcul = N + croissance - consommation;

        nouvellesPopulations[i] = (int) nouvellePopulationCalcul;
        // eviter les populations negatives
        if (nouvellesPopulations[i] < 0) {
            nouvellesPopulations[i] = 0;
        }
    }
    // Mettre a jour les populations dans le tableau `sommets`
    for (int i = 0; i < nombreSommets; i++) {
        sommets[i].population = nouvellesPopulations[i];
    }
}

void afficherPopulations(int etape) {
    printf("\n--- Etape %d ---\n", etape);
    printf("%-15s %-20s\n", "Nom", "Population");

    printf("---------------------------------\n");
    for (int i = 0; i < nombreSommets; i++) {
        printf("%-15s %-20d\n",
               sommets[i].nom,          // Nom de l'espece
               (int)sommets[i].population  // Population arrondie a un entier
        );
    }
}

void simulerPopulations(int etapes) {
    int populationsInitiales[MAX_SOMMETS];
    double tauxInitiales[MAX_SOMMETS];

    // Sauvegarder les populations initiales
    for (int i = 0; i < nombreSommets; i++) {
        populationsInitiales[i] = sommets[i].population;
        tauxInitiales[i] = sommets[i].tauxCroissance;
    }
    reinitialiserFichier("chart.txt");
    // Supprimer les anciens fichiers de donnees pour eviter les conflits
    //reinitialiserFichierDonnees();

    // Simulation des etapes
    sauvegarderPopulationsDansFichier("chart.txt", etapes);
    for (int t = 1; t <= etapes; t++) {
        //enregistrerEvolutionPopulations(t - 1); // Enregistrer les donnees de l'etape
        afficherPopulations(t - 1);            // Afficher les populations pour l'etape actuelle
        mettreAJourPopulations();
        sauvegarderPopulationsDansFichier("chart.txt", etapes);// Mettre a jour les populations pour l'etape suivante
    }
    printf("\n--------------------------------------------------------------------------------\n");
    printf("| %-16s | %-14s | %-16s | %-80s |\n",
           "Nom", "Croissance", "Consommation", "Commentaires");
    printf("--------------------------------------------------------------------------------\n");

    for (int i = 0; i < nombreSommets; i++) {
        int N = populationsInitiales[i];  // Population initiale
        double r = tauxInitiales[i];      // Taux de croissance initial
        int K = calculerCapaciteCharge(sommets[i].id);
        double consommation = calculerQuantiteConsommee(sommets[i].id);
        if (K == 0){
            K = 10000;
        }

        double croissance = r * N * (1 - (double)N / K);
        double nouvellePopulationCalcul = N + croissance - consommation;

        char commentaires[256] = "";
        char commentairesSupp[128] = ""; // Pour les lignes supplémentaires

        // Generer des commentaires bases sur l'evolution
        if (nouvellePopulationCalcul > N) {
            if (consommation == 0) {
                snprintf(commentaires, sizeof(commentaires),
                         "Faible croissance, pas de predateurs");
            } else {
                snprintf(commentaires, sizeof(commentaires),
                         "Haute croissance, faible consommation");
            }
        } else if (nouvellePopulationCalcul < N) {
            if (consommation == 0) {
                snprintf(commentaires, sizeof(commentaires),
                         "Faible croissance, pas de predateurs");
            } else {
                snprintf(commentaires, sizeof(commentaires),
                         "Forte consommation, faible croissance");
            }
        }

        if (consommation > K * 0.8) {
            snprintf(commentairesSupp + strlen(commentairesSupp), sizeof(commentairesSupp) - strlen(commentairesSupp),
                     "Impacte par forte consommation des predateurs\n");
        }
        if (K < N) {
            snprintf(commentairesSupp + strlen(commentairesSupp), sizeof(commentairesSupp) - strlen(commentairesSupp),
                     "Limite par capacite (%d)\n", K);
        }

        // Affichage principal avec lignes supplementaires
        printf("| %-16s | %-14.6f | %-16.6f | %-80s |\n",
               sommets[i].nom, r, consommation, commentaires);

        if (strlen(commentairesSupp) > 0) {
            printf("| %-16s | %-14s | %-16s | %-80s |\n",
                   "", "", "", commentairesSupp);
        }
    }

    printf("--------------------------------------------------------------------------------\n");

    afficherPopulations(etapes); // Afficher les populations finales

    // Reinitialiser les populations a leur etat initial
    reinitialiserPopulations(populationsInitiales, tauxInitiales);
}

void reinitialiserPopulations() {
    if (sommets == NULL || nombreSommets <= 0) {
        printf("Erreur : aucun sommet disponible.\n");
        return;
    }

    // Demander si l'utilisateur veut reinitialiser un sommet
    char reinitialiser;
    while (1) {
        printf("Voulez-vous reinitialiser un sommet ? (1/0) : ");
        if (scanf(" %c", &reinitialiser) == 1 && (reinitialiser == '1' || reinitialiser == '0')) {
            break;
        }
        printf("Erreur : veuillez entrer '1' pour Oui ou '0' pour Non.\n");
        while (getchar() != '\n'); // Vider le tampon
    }

    if (reinitialiser == '0') {
        return; // Quitter la fonction si l'utilisateur ne veut pas reinitialiser
    }

    int continuer = 1; // Variable pour contrÃ´ler la boucle

    while (continuer) {
        int sommetId;

        // Selectionner un sommet
        while (1) {
            printf("Entrez l'ID du sommet que vous voulez reinitialiser : ");
            if (scanf("%d", &sommetId) == 1 && sommetId > 0 && sommetId <= nombreSommets) {
                break;
            }
            printf("Entree invalide. Veuillez entrer un ID valide (entre 1 et %d).\n", nombreSommets);
            while (getchar() != '\n'); // Vider le tampon
        }

        int index = sommetId - 1;

        // Confirmer la reinitialisation pour la population
        char choixPopulation;
        while (1) {
            printf("Voulez-vous reinitialiser la population de %s (actuelle : %d) a %d ? (1/0) : ",
                   sommets[index].nom, sommets[index].population, sommets[index].populationInitiale);
            if (scanf(" %c", &choixPopulation) == 1 && (choixPopulation == '1' || choixPopulation == '0')) {
                break;
            }
            printf("Erreur : veuillez entrer '1' pour Oui ou '0' pour Non.\n");
            while (getchar() != '\n'); // Vider le tampon
        }

        if (choixPopulation == '1') {
            sommets[index].population = sommets[index].populationInitiale;
            printf("Population de %s reinitialisee a %d.\n", sommets[index].nom, sommets[index].populationInitiale);
        } else {
            printf("Population de %s conservee.\n", sommets[index].nom);
        }

        // Confirmer la reinitialisation pour le taux de croissance
        char choixTaux;
        while (1) {
            printf("Voulez-vous reinitialiser le taux de croissance de %s (actuel : %.2f) a %.2f ? (1/0) : ",
                   sommets[index].nom, sommets[index].tauxCroissance, sommets[index].tauxCroissanceInitial);
            if (scanf(" %c", &choixTaux) == 1 && (choixTaux == '1' || choixTaux == '0')) {
                break;
            }
            printf("Erreur : veuillez entrer '1' pour Oui ou '0' pour Non.\n");
            while (getchar() != '\n'); // Vider le tampon
        }

        if (choixTaux == '1') {
            sommets[index].tauxCroissance = sommets[index].tauxCroissanceInitial;
            printf("Taux de croissance de %s reinitialise a %.2f.\n", sommets[index].nom, sommets[index].tauxCroissanceInitial);
        } else {
            printf("Taux de croissance de %s conserve.\n", sommets[index].nom);
        }

        // Demander si l'utilisateur veut continuer avec un autre sommet
        char choixContinuer;
        while (1) {
            printf("Voulez-vous reinitialiser un autre sommet ? (1/0) : ");
            if (scanf(" %c", &choixContinuer) == 1 && (choixContinuer == '1' || choixContinuer == '0')) {
                break;
            }
            printf("Erreur : veuillez entrer '1' pour Oui ou '0' pour Non.\n");
            while (getchar() != '\n'); // Vider le tampon
        }

        if (choixContinuer == '0') {
            continuer = 0;
        }
    }
}
void modifierSommet() {
    if (sommets == NULL || nombreSommets <= 0) {
        printf("Erreur : aucun sommet disponible.\n");
        return;
    }

    int continuer = 1; // Variable pour contrÃ´ler la boucle

    while (continuer) {
        int sommetId;
        while (1) {
            printf("Entrez l'ID du sommet : ");
            if (scanf("%d", &sommetId) == 1 && sommetId > 0 && sommetId <= nombreSommets) {
                break;
            }
            printf("Entree invalide. Veuillez entrer un ID valide (entre 1 et %d).\n", nombreSommets);
            while (getchar() != '\n'); // Vider le tampon
        }

        int index = sommetId - 1;

        // Demander la nouvelle population
        int nouvellePopulation;
        while (1) {
            printf("Entrez la nouvelle population pour %s (actuelle : %d) : ",
                   sommets[index].nom, sommets[index].population);
            if (scanf("%d", &nouvellePopulation) == 1 && nouvellePopulation >= 0) {
                break;
            }
            printf("Erreur : veuillez entrer un entier positif pour la population.\n");
            while (getchar() != '\n'); // Vider le tampon
        }

        // Demander le nouveau taux de croissance
        double nouvTaux;
        while (1) {
            printf("Entrez le nouveau taux de croissance pour %s (actuel : %.2f) : ",
                   sommets[index].nom, sommets[index].tauxCroissance);
            if (scanf("%lf", &nouvTaux) == 1) {
                break;
            }
            printf("Erreur : veuillez entrer un nombre reel pour le taux de croissance.\n");
            while (getchar() != '\n'); // Vider le tampon
        }

        // Modifier les valeurs
        sommets[index].population = nouvellePopulation;
        sommets[index].tauxCroissance = nouvTaux;

        printf("La population de %s a ete modifiee a %d.\n", sommets[index].nom, nouvellePopulation);
        printf("Le taux de croissance de %s a ete modifie a %.2f.\n", sommets[index].nom, nouvTaux);

        // Demander si l'utilisateur veut modifier une autre espece
        printf("Voulez-vous modifier les valeurs d'une autre espece ? (1 = Oui, 0 = Non) : ");
        while (scanf("%d", &continuer) != 1 || (continuer != 1 && continuer != 0)) {
            printf("Erreur : Entree invalide. Veuillez entrer 1 ou 0.\n");
            while (getchar() != '\n'); // Vider le tampon
        }
    }
}