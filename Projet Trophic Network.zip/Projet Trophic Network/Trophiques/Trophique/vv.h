//
// Created by marti on 29/11/2024.
//

#ifndef UNTITLED9_VV_H
#define UNTITLED9_VV_H
#include <stdbool.h>
#include "cc.h" // Inclure un fichier contenant les structures si nécessaire
// dans un fichier .h
extern int nombreSommets;
extern Sommet sommets[MAX_SOMMETS];
extern int adj[MAX_SOMMETS][MAX_SOMMETS];
extern int nombreArcs;
extern Arc arcs[MAX_ARCS];
extern int adjTranspose[MAX_SOMMETS][MAX_SOMMETS]; // Matrice transposée

void premiersMaillons();
void derniersMaillons();
void sommetsSourceUnique();
void explorerChainesAlimentaires(int sommetActuel, int chemin[], int tailleChemin, int niveaux[], int *indexNiveaux, int idEspece, bool afficherExemple);
void afficherNiveauxTrophiques();
double CentraliteRadiale(int sommetId, int *degreEntree, int *degreSortie);
void AfficherCentraliteRadiale();
double* CentraliteIntermediaire();
void AfficherCentraliteIntermediaire(double* centraliteIntermediaire);
bool sommetARelation(int sommetId, bool verifierSuccesseurs);
#endif //UNTITLED9_VV_H
