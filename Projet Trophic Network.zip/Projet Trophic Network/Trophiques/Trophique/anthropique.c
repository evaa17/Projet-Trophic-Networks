//
// Created by marti on 08/12/2024.
//

#include "anthropique.h"
#include "vv.h"
#include "cc.h"
extern char fichier[100]; // Déclaration externe


void appliquerImpactsAnthropiques(Ecosysteme *ecosysteme, EvolutionPopulation *historique, int *tailleHistorique, const char *fichierCharge) {
    printf("\n--- Application des impacts anthropiques ---\n");

    // Si le fichier chargé est "123.txt", appliquer des impacts spécifiques à l'océan
    if (strcmp(fichierCharge, "123.txt") == 0) {
        int nombrePecheurs;
        printf("Entrez le nombre de pecheurs de crevettes (en milliers) : ");
        scanf("%d", &nombrePecheurs);
        MiseaJour_Pop(ecosysteme, nombrePecheurs, historique, *tailleHistorique);
        (*tailleHistorique)++;
        printf("Impact anthropique applique pour l'ocean avec succes.\n");
    }
        // Si le fichier chargé est "2.txt", appliquer des impacts spécifiques à la savane (braconnage des rhinocéros)
    else if (strcmp(fichierCharge, "2.txt") == 0) {
        int nombreBraconniers;
        printf("Entrez le nombre de braconniers de rhinoceros (en milliers) : ");
        scanf("%d", &nombreBraconniers);
        mettreAJourBraconnage(ecosysteme, nombreBraconniers, historique, *tailleHistorique);
        (*tailleHistorique)++;
        printf("Impact anthropique applique pour le braconnage des rhinoceros avec succes.\n");
    } else {
        printf("Le fichier charge n'est pas lie a un impact anthropique specifique.\n");
    }
}
// Réduction récursive des populations
void ajusterPopulationRecursivement(int sommetId, double facteurAjustement) {
    // Ajuster la population de ce sommet
    sommets[sommetId - 1].population *= facteurAjustement;

    // Si la population devient inférieure à 0, on la met à 0
    if (sommets[sommetId - 1].population < 0) sommets[sommetId - 1].population = 0;

    // Appliquer le même ajustement aux prédateurs de ce sommet
    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet2 == sommetId) {
            ajusterPopulationRecursivement(arcs[i].sommet1, facteurAjustement);
        }
    }
}

void MiseaJour_Pop(Ecosysteme *ecosysteme, int nombrePecheurs, EvolutionPopulation *historique, int tailleHistorique) {
    // Calculer le facteur d'ajustement pour les crevettes
    double facteurAjustement = 1.0 - (double)(nombrePecheurs) / 10.0;

    // Si le nombre de pêcheurs diminue, les crevettes augmentent proportionnellement
    if (nombrePecheurs < historique[tailleHistorique - 1].nombrePecheurs) {
        facteurAjustement = 1.0 + (double)(historique[tailleHistorique - 1].nombrePecheurs - nombrePecheurs) / 10.0;
    }

    // Appliquer l'ajustement aux populations des crevettes
    if (sommets[5].population > 0) { // Crevettes (ID 6)
        sommets[5].population *= facteurAjustement;
        if (sommets[5].population < 0) sommets[5].population = 0; // Éteindre si < 0
    }

    // Appliquer l'ajustement aux prédateurs qui mangent des crevettes
    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet2 == 6) { // Si les crevettes sont une proie
            int predateurId = arcs[i].sommet1;

            // Si la population du prédateur est encore supérieure à 0
            if (sommets[predateurId - 1].population > 0) {
                // Calculer le facteur d'ajustement pour les prédateurs en fonction des crevettes
                double facteurPredateur = 1.0 - (double)(nombrePecheurs) / 10.0;
                sommets[predateurId - 1].population *= facteurPredateur;
                if (sommets[predateurId - 1].population < 0) sommets[predateurId - 1].population = 0; // Éteindre si < 0
            }
        }
    }

    // Ajouter l'évolution à l'historique
    historique[tailleHistorique].annee = tailleHistorique;
    historique[tailleHistorique].populationCrevettes = sommets[5].population;  // Population actuelle des crevettes
    historique[tailleHistorique].populationPredateurs = sommets[1].population; // Population actuelle des prédateurs (si ID de prédateur est 1)
    historique[tailleHistorique].nombrePecheurs = nombrePecheurs;

    // Messages d'extinction
    if (sommets[5].population <= 0) {
        printf("Les crevettes se sont eteintes.\n");
    }
    if (sommets[1].population <= 0) {
        printf("Les predateurs se sont eteints.\n");
    }
}

void mettreAJourBraconnage(Ecosysteme *ecosysteme, int nombreBraconniers, EvolutionPopulation *historique, int tailleHistorique) {
    // Calculer le facteur d'ajustement
    double facteurAjustement = 1.0 - (double)(nombreBraconniers) / 10.0;

    // Appliquer l'ajustement aux populations des rhinocéros
    if (sommets[11].population > 0) { // ID des rhinocéros (index 11 pour ID 12)
        sommets[11].population *= facteurAjustement;
        if (sommets[11].population < 0) sommets[11].population = 0; // Éteindre l'espèce si < 0
    }

    // Appliquer l'ajustement aux prédateurs qui mangent des rhinocéros
    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet2 == 12) { // Si le rhinocéros est une proie
            int predateurId = arcs[i].sommet1;
            if (sommets[predateurId - 1].population > 0) {
                sommets[predateurId - 1].population *= facteurAjustement;
                if (sommets[predateurId - 1].population < 0) sommets[predateurId - 1].population = 0; // Éteindre si < 0
            }
        }
    }

    // Enregistrer l'évolution dans l'historique
    historique[tailleHistorique].annee = tailleHistorique;
    historique[tailleHistorique].populationCrevettes = sommets[11].population;  // Utilisé ici pour les rhinocéros
    historique[tailleHistorique].populationPredateurs = sommets[13].population; // Exemple avec un prédateur, à ajuster si nécessaire
    historique[tailleHistorique].nombrePecheurs = nombreBraconniers; // Utilisé ici pour les braconniers

    // Message si une espèce s'éteint
    if (sommets[11].population <= 0) {
        printf("Les rhinoceros se sont eteints.\n");
    }
}

// Initialisation de l'écosystème avec les populations de base et les taux de croissance
void initialiserEcosysteme(Ecosysteme *ecosysteme) {
    ecosysteme->populationCrevettes = 50;  // Population initiale de crevettes (en milliers)
    ecosysteme->populationPredateurs = 10; // Population initiale de prédateurs (en milliers)
    ecosysteme->tauxCroissanceCrevettes = 0.1;  // Croissance des crevettes par an
    ecosysteme->tauxCroissancePredateurs = 0.05; // Croissance des prédateurs par an
    ecosysteme->capaciteChargeCrevettes = 1000;  // Capacité de charge des crevettes
    ecosysteme->capaciteChargePredateurs = 100;  // Capacité de charge des prédateurs
}

// Affichage de l'évolution des populations
void afficherEvolution(EvolutionPopulation *historique, int tailleHistorique) {
    for (int i = 0; i < tailleHistorique; i++) {
        printf("%d\t%d\t\t%d\t\t%d\n",
               historique[i].annee,
               historique[i].populationCrevettes,
               historique[i].populationPredateurs,
               historique[i].nombrePecheurs);
    }
}
