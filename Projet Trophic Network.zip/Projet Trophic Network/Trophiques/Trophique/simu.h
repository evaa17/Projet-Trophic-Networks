//
// Created by marti on 08/12/2024.
//

#ifndef UNTITLED9_SIMU_H
#define UNTITLED9_SIMU_H
#include <stdbool.h>
void simulationSuppressionSommet(int sommetId);
bool sommetPeutEtreRemplace(int sommetId);
bool sommetEstEssentiel(int sommetId);
#endif //UNTITLED9_SIMU_H
