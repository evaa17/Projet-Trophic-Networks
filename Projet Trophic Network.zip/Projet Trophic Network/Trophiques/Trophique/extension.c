//
// Created by marti on 07/12/2024.
//

#include "extension.h"
#include <string.h>
#include <stdio.h>
#include "vv.h"
#include <stdbool.h>

void sauvegarderPopulationsDansFichier(const char* nomFichier, int numeroEtape) {
    static int etapeCourante = 0; // Compteur d'étape (incrémente à chaque appel)

    FILE *fichier = fopen(nomFichier, "a");
    if (fichier == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier %s pour l'écriture.\n", nomFichier);
        return;
    }

    // Si c'est la première étape, écrire les noms des espèces en tête
    if (etapeCourante == 0) {
        fprintf(fichier, "Etape ");
        for (int i = 0; i < nombreSommets; i++) {
            fprintf(fichier, "%s ", sommets[i].nom);
        }
        fprintf(fichier, "\n"); // Nouvelle ligne après les noms des espèces
    }

    // Écrire les données de l'étape courante
    fprintf(fichier, "%d ", etapeCourante); // Écrire l'étape
    for (int i = 0; i < nombreSommets; i++) {
        fprintf(fichier, "%d ", (int)sommets[i].population);
    }
    fprintf(fichier, "\n"); // Nouvelle ligne pour la prochaine étape

    etapeCourante++; // Incrémenter l'étape pour la prochaine simulation
    fclose(fichier);
}


void genererScriptGnuplot(const char *nomFichierTexte, const char *nomFichierScript) {
    FILE *fichierTexte = fopen(nomFichierTexte, "r");
    if (fichierTexte == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier %s.\n", nomFichierTexte);
        return;
    }

    // Ouvrir le fichier de script gnuplot en mode ecriture
    FILE *fichierScript = fopen(nomFichierScript, "w");
    if (fichierScript == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier %s.\n", nomFichierScript);
        fclose(fichierTexte);
        return;
    }

    // Lire la premiere ligne du fichier (noms des especes)
    char ligne[1024];
    if (fgets(ligne, sizeof(ligne), fichierTexte) == NULL) {
        printf("Erreur : impossible de lire les donnees du fichier.\n");
        fclose(fichierTexte);
        fclose(fichierScript);
        return;
    }

    // Extraire les noms des especes
    char *token = strtok(ligne, " \n");
    int compteurEspeces = 0;
    char nomsEspeces[100][50]; // Tableau pour stocker les noms des especes
    while (token != NULL) {
        strcpy(nomsEspeces[compteurEspeces], token);
        compteurEspeces++;
        token = strtok(NULL, " \n");
    }

    // Generer le script gnuplot
    fprintf(fichierScript, "set title \"Evolution des populations par etape\"\n");
    fprintf(fichierScript, "set xlabel \"Etapes\"\n");
    fprintf(fichierScript, "set ylabel \"Population\"\n");
    fprintf(fichierScript, "set style data linespoints\n");
    fprintf(fichierScript, "set key outside\n");
    fprintf(fichierScript, "set grid\n");
    fprintf(fichierScript, "set terminal wxt size 800,600\n");

    // Construire la commande plot
    fprintf(fichierScript, "plot ");
    for (int i = 0; i < compteurEspeces; i++) {
        fprintf(fichierScript, "\"%s\" using 1:%d title \"%s\" with linespoints", nomFichierTexte, i+2, nomsEspeces[i]);
        if (i < compteurEspeces - 1) {
            fprintf(fichierScript, ", \\\n");
        }
    }
    fprintf(fichierScript, "\n");

    // Fermer les fichiers
    fclose(fichierTexte);
    fclose(fichierScript);
    printf("\nLe fichier %s a ete genere avec succes.\n", nomFichierScript);
}

void reinitialiserFichier(const char* nomFichier) {
    FILE *fichier = fopen(nomFichier, "w");
    if (fichier == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier %s pour l'ecriture.\n", nomFichier);
        return;
    }
    // Le fichier est maintenant vide
    fclose(fichier);
    printf("\nLe fichier %s a ete reinitialise.\n", nomFichier);
}

/*void afficherGrapheDot(const char* fichierDot) {
    // Verifier si le fichier .dot existe
    FILE *fichier = fopen(fichierDot, "r");
    if (fichier == NULL) {
        printf("Erreur : impossible d'ouvrir le fichier %s.\n", fichierDot);
        return;
    }
    fclose(fichier);

    // Commande pour generer le fichier PNG avec Graphviz
    char commandeGenerer[200];
    snprintf(commandeGenerer, sizeof(commandeGenerer), "dot -Tpng %s -o graphe.png", fichierDot);

    int ret = system(commandeGenerer);
    if (ret != 0) {
        printf("Erreur lors de la generation de l'image avec Graphviz.\n");
        return;
    }

    // Commande pour afficher le fichier PNG
    char commandeAfficher[200];
#ifdef _WIN32
    snprintf(commandeAfficher, sizeof(commandeAfficher), "start graphe.png");
#else
    snprintf(commandeAfficher, sizeof(commandeAfficher), "xdg-open graphe.png");
#endif

    ret = system(commandeAfficher);
    if (ret != 0) {
        printf("Erreur lors de l'ouverture de l'image graphe.png.\n");
    }
}*/