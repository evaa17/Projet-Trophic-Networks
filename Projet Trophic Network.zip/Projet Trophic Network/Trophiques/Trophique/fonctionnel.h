//
// Created by marti on 30/11/2024.
//
#ifndef UNTITLED9_FONCTIONNEL_H
#define UNTITLED9_FONCTIONNEL_H
#include "cc.h"

extern Sommet sommets[MAX_SOMMETS];
extern Arc arcs[MAX_ARCS];
extern int nombreSommets;
extern int nombreArcs;
int calculerCapaciteCharge(int sommetId);
void mettreAJourPopulations();
void afficherPopulations(int etape);
void simulerPopulations(int etapes);
double calculerQuantiteConsommee(int sommetId);
void modifierSommet();
void reinitialiserPopulations();

#endif //UNTITLED9_FONCTIONNEL_H
