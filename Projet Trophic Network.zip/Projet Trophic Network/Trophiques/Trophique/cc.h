//
// Created by marti on 29/11/2024.
//

#ifndef UNTITLED9_CC_H
#define UNTITLED9_CC_H
#ifndef CC_H
#define CC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Définition des constantes
#define MAX_SOMMETS 100
#define MAX_ARCS 200

// Structures
typedef struct {
    int id;
    char nom[50];
    int niveauTrophique;
    int population;// N(t)
    int populationInitiale;
    double tauxCroissance;
    double tauxCroissanceInitial;// r
    double capaciteCharge;
} Sommet;

typedef struct {
    int sommet1;
    int sommet2;
    double coefficient;
} Arc;

typedef struct {
    int nombreCFC;
    int cfc[MAX_SOMMETS][MAX_SOMMETS];
    int tailleCFC[MAX_SOMMETS];
    int composante[MAX_SOMMETS];
} CFCData;

// Déclarations des fonctions
void initialiser(CFCData *data);
void trouverCFC(CFCData *data);
int chargerGraphe(const char* fichier);
void dfs(int sommet, int matrice[MAX_SOMMETS][MAX_SOMMETS], int enregistrerPile);
void explorerCFC(int sommet, int matrice[MAX_SOMMETS][MAX_SOMMETS], int cfcId, CFCData *data);
int trouverComposantes(CFCData *data);
void reiniCompo(int composanteChoisie,CFCData *data);
void gererComposantes(CFCData *data);
void analyserConnexite(CFCData*data);
int calculerHauteurTrophique();
double calculerDensiteLiaison();
double calculerVarianceDegre();
void afficherComplexite();

// Fonctions supplémentaires
void afficherArcs();
void afficherSommets();
void afficherNombreSommets();
void afficherSuccesseurs(int sommetid);
void afficherPredecesseurs(int sommetid);
int sommetExiste(int sommetId);


#endif // CC_H

#endif //UNTITLED9_CC_H
