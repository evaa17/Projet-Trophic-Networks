//
// Created by marti on 07/12/2024.
//

#ifndef UNTITLED9_EXTENSION_H
#define UNTITLED9_EXTENSION_H
#include "cc.h"
#include "vv.h"

void sauvegarderPopulationsDansFichier(const char* nomFichier, int numeroEtape);
//void afficherGrapheDot(const char* fichierDot);
void reinitialiserFichier(const char* nomFichier);
void genererScriptGnuplot(const char*nomFichierTexte, const char*nomFichierScript);

#endif //UNTITLED9_EXTENSION_H
