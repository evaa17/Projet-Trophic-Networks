#include <stdio.h>
#include <stdbool.h>
#include "vv.h"
//PARTIE STRUCTUREL
// Fonction pour vérifier les relations d'un sommet
bool sommetARelation(int sommetId, bool verifierSuccesseurs) {
    for (int j = 0; j < nombreArcs; j++) {
        if (verifierSuccesseurs && arcs[j].sommet1 == sommetId) {
            return true; // A un successeur
        }
        if (!verifierSuccesseurs && arcs[j].sommet2 == sommetId) {
            return true; // A un prédécesseur
        }
    }
    return false; // Pas de relation trouve
}
// Fonction pour afficher les derniers maillons (espèces sans prédateurs)
void derniersMaillons() {
    printf("\nDerniers Maillons (especes sans predateurs):\n");
    for (int i = 0; i < nombreSommets; i++) {
        // on verif si le sommet n'a pas de successeur
        if (sommets[i].niveauTrophique >= 0 && !sommetARelation(sommets[i].id, false)) {
            printf("ID: %d, Nom: %s\n", sommets[i].id, sommets[i].nom);
        }
    }
}
// Fonction pour afficher les premiers maillons (producteurs primaires)
void premiersMaillons() {
    printf("\nProducteurs primaires:\n");
    for (int i = 0; i < nombreSommets; i++) {
        //verif si le sommet n'a pas de predecesseur
        if (sommets[i].niveauTrophique >= 0 && !sommetARelation(sommets[i].id, true)) {
            printf("ID: %d, Nom: %s\n", sommets[i].id, sommets[i].nom);
        }
    }
}
// Fonction pour afficher les espèces avec une seule source d'alimentation (un seul predecesseur)
void sommetsSourceUnique() {
    printf("\nEspeces avec une seule source d'alimentation :\n");
    for (int i = 0; i < nombreSommets; i++) {
        if (sommets[i].niveauTrophique >= 0) {
            int compteurPredecesseurs = 0;
            for (int j = 0; j < nombreArcs; j++) {
                if (arcs[j].sommet2 == sommets[i].id) {
                    compteurPredecesseurs++;
                }
            }
            if (compteurPredecesseurs == 1) { // un seul donc afficher
                printf("ID: %d, Nom: %s\n", sommets[i].id, sommets[i].nom);
            }
        }
    }
}

// Fonction récursive pour explorer les chaînes alimentaires
void explorerChainesAlimentaires(int sommetActuel, int chemin[], int tailleChemin, int niveaux[], int *indexNiveaux, int idEspece, bool afficherExemple) {
    chemin[tailleChemin] = sommetActuel; // Ajouter le sommet au chemin
    tailleChemin++;

    bool aUnPredecesseur = false;

    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet1 == sommetActuel) { // Trouver les prédécesseurs
            aUnPredecesseur = true;
            explorerChainesAlimentaires(arcs[i].sommet2, chemin, tailleChemin, niveaux, indexNiveaux, idEspece, afficherExemple);
        }
    }

    // Si le sommet n'a pas de prédécesseur, on atteint la fin d'une chaîne
    if (!aUnPredecesseur) {
        niveaux[*indexNiveaux] = tailleChemin; // Ajouter le niveau trophique
        (*indexNiveaux)++;

        if (afficherExemple) { // Afficher les chaines
            for (int j = tailleChemin - 1; j >= 0; j--) {
                printf("%s", sommets[chemin[j] - 1].nom);
                if (j > 0) printf(" -> ");
            }
            printf("\n");
        }
    }
}

// Fonction pour afficher les niveaux trophiques d'une espèce donnée
void afficherNiveauxTrophiques() {
    int idEspece;
    printf("\nEntrez l'ID de l'espece cible : ");
    scanf("%d", &idEspece);

    // Vérification avec la fonction sommetExiste
    if (!sommetExiste(idEspece)) {
        printf("Erreur : ID invalide.\n");
        return;
    }

    printf("\nNiveaux trophiques pour l'espece %s :\n", sommets[idEspece - 1].nom);
    int chemin[MAX_SOMMETS];
    int niveaux[MAX_SOMMETS];
    int indexNiveaux = 0;

    // Explorer toutes les chaînes alimentaires
    explorerChainesAlimentaires(idEspece, chemin, 0, niveaux, &indexNiveaux, idEspece, false);

    // Trouver les niveaux trophiques uniques
    int niveauxUniques[MAX_SOMMETS];
    int indexUniques = 0;

    for (int i = 0; i < indexNiveaux; i++) {
        bool estUnique = true;
        for (int j = 0; j < indexUniques; j++) {
            if (niveaux[i] == niveauxUniques[j]) {
                estUnique = false;
                break;
            }
        }
        if (estUnique) {
            niveauxUniques[indexUniques] = niveaux[i];
            indexUniques++;
        }
    }

    // Affichage des niveaux trophiques
    if (indexUniques == 1) {
        printf("%s a un seul niveau trophique : %d\n", sommets[idEspece - 1].nom, niveauxUniques[0]);
    } else {
        printf("%s a plusieurs niveaux trophiques : ", sommets[idEspece - 1].nom);
        for (int i = 0; i < indexUniques; i++) {
            printf("%d ", niveauxUniques[i]);
        }
        printf("\n");
    }

    printf("\nChaines alimentaires :\n");

    // Réafficher chaînes alimentaires
    explorerChainesAlimentaires(idEspece, chemin, 0, niveaux, &indexNiveaux, idEspece, true);
}
//sources dependances ajout

// Fonction qui calcule la centralité radiale et retourne les degrés
// centralite radiale : mesure les deg entrant et sortant, et en faire une moyenne pour chaque sommet
double CentraliteRadiale(int sommetId, int *degreEntree, int *degreSortie) {
    *degreEntree = 0;
    *degreSortie = 0;

    // Calcul des degrés pour le sommet donné
    for (int j = 0; j < nombreSommets; j++) {
        if (adj[sommetId][j] == 1) {
            (*degreEntree)++;  // Arc de sommetId à j
        }
        if (adjTranspose[sommetId][j] == 1) {
            (*degreSortie)++;  // Arc de j à sommetId
        }
    }

    // moyenne des deg
    return 0.5 * (*degreEntree + *degreSortie);
}

void AfficherCentraliteRadiale() {
    printf("+---------+------------------+----------------+----------------+---------------------+\n");
    printf("| Sommet  | Nom              | Degre entrant  | Degre sortant  | Centralite radiale  |\n");
    printf("+---------+------------------+----------------+----------------+---------------------+\n");
    // Affichage des informations pour chaque sommet
    for (int i = 1; i <= nombreSommets; i++) {
        int degreEntree = 0;
        int degreSortie = 0;
        double centraliteRadiale = CentraliteRadiale(i, &degreEntree, &degreSortie);
        printf("| %-7d | %-16s | %-14d | %-14d | %-19.2f |\n",
               i, sommets[i - 1].nom, degreEntree, degreSortie, centraliteRadiale);
    }
    printf("+---------+------------------+----------------+----------------+---------------------+\n");
}

//Calcule la centralite intermediaire pour chaque sommet
// centralite intermediaire: importance d'un sommet dans le reseau, le nombre de fois ou un sommet est l'intermediaire
// Utilisation du BFS pour trouver le nombre de plus courts chemins passant par chaque sommets
double* CentraliteIntermediaire() {
    static double centraliteIntermediaire[MAX_SOMMETS]; // Tableau statique pour stockage

    // Initialiser les valeurs de centralité à zéro
    memset(centraliteIntermediaire, 0, sizeof(centraliteIntermediaire));

    for (int source = 1; source <= nombreSommets; source++) {
        // Structures nécessaires pour BFS
        int distance[MAX_SOMMETS], nombreChemins[MAX_SOMMETS];
        double dependance[MAX_SOMMETS];
        int predecesseurs[MAX_SOMMETS][MAX_SOMMETS];
        int taillePredecesseurs[MAX_SOMMETS];

        memset(distance, -1, sizeof(distance)); // -1 signifie "non visité"
        memset(nombreChemins, 0, sizeof(nombreChemins));
        memset(dependance, 0, sizeof(dependance));
        memset(taillePredecesseurs, 0, sizeof(taillePredecesseurs));
        distance[source] = 0;
        nombreChemins[source] = 1; //un seul chemin

        // File pour BFS
        int file[MAX_SOMMETS], debut = 0, fin = 0;
        file[fin++] = source;

        // BFS pour calculer les plus courts chemins
        while (debut < fin) {
            int sommet = file[debut++];
            for (int voisin = 1; voisin <= nombreSommets; voisin++) {
                if (adj[sommet][voisin]) { // Arc existant
                    if (distance[voisin] == -1) {
                        // Voisin visité pour la première fois
                        distance[voisin] = distance[sommet] + 1;
                        file[fin++] = voisin;
                    }
                    // Si le voisin est sur le plus court chemin
                    if (distance[voisin] == distance[sommet] + 1) {
                        nombreChemins[voisin] += nombreChemins[sommet];
                        predecesseurs[voisin][taillePredecesseurs[voisin]++] = sommet;// ajouter a la liste des predecesseurs
                    }
                }
            }
        }

        // dependance inverse
        while (fin > 0) {
            int sommet = file[--fin];
            for (int i = 0; i < taillePredecesseurs[sommet]; i++) {
                int pred = predecesseurs[sommet][i];
                double fraction = (double)nombreChemins[pred] / nombreChemins[sommet];
                dependance[pred] += fraction * (1 + dependance[sommet]);
            }
            // Ne pas inclure le sommet source dans sa propre centralité
            if (sommet != source) {
                centraliteIntermediaire[sommet] += dependance[sommet];// ajout de la dependance a centralite
            }
        }
    }

    return centraliteIntermediaire;
}

void AfficherCentraliteIntermediaire(double* centraliteIntermediaire) {
    printf("+---------+--------------------------+\n");
    printf("| Sommet  | Centralite Intermediaire |\n");
    printf("+---------+--------------------------+\n");
    for (int i = 1; i <= nombreSommets; i++) {
        printf("| %-7d | %-24.4f |\n", i, centraliteIntermediaire[i]);
    }
    printf("+---------+--------------------------+\n");
}
