set title "Évolution des populations par étape"
set xlabel "Étapes"
set ylabel "Population"
set style data linespoints
set key outside
set grid
set terminal wxt size 800,600

plot for [i=2:*] "chart.txt" using 1:i title columnheader(i) with linespoints