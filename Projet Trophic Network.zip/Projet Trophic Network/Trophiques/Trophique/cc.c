//
// Created by marti on 29/11/2024.
//FICHIER PARTIE FONDAMENTALE
// -------------------------DECLARATIONS DES VARIABLES-----------------------------------------------------------------
#include "cc.h"
#define MAX_SOMMETS 100
#define MAX_ARCS 200
Sommet sommets[MAX_SOMMETS];
Arc arcs[MAX_ARCS];

// Matrices d'adjacence utilisées globalement pour représenter différents types de graphes
// Elles doivent être accessibles à plusieurs fonctions, y compris celles de traitement des composantes
int adj[MAX_SOMMETS][MAX_SOMMETS]; // Matrice d'adjacence
int adjTranspose[MAX_SOMMETS][MAX_SOMMETS]; // Matrice transposée
int adjNonOriente[MAX_SOMMETS][MAX_SOMMETS]; // Matrice non orientée
// Tableau pour marquer les sommets visités, utilisé dans diverses fonctions DFS
// Doit être partagé pour éviter de redéclarer à chaque appel récursif
int visite[MAX_SOMMETS];
// Pile utilisée pour l'ordre de finition dans l'algorithme de Kosaraju
// Nécessaire pour stocker les sommets à travers plusieurs appels DFS
int pile[MAX_SOMMETS];
int sommetPile = 0; // Indice du sommet au sommet de la pile
// Variables pour suivre les informations globales sur le graphe
int nombreSommets = 0; // Nombre total de sommets
int nombreArcs = 0;    // Nombre total d'arcs




// -----------------------------------------------INIT GRAPHE ---------------------------------------------------------------------------------
// Fonction d'initialisation du graphe et de ses structures associées
// Cette fonction réinitialise les matrices d'adjacence, les données des sommets et arcs, ainsi que les structures de suivi.
//memset : remplit ou reinitialise un bloc memoire avec une valeur specifique
void initialiser(CFCData *data) {
    memset(adj, 0, sizeof(adj));
    memset(adjTranspose, 0, sizeof(adjTranspose));
    memset(adjNonOriente, 0, sizeof(adjNonOriente));
    memset(visite, 0, sizeof(visite));
    sommetPile = 0;
    data->nombreCFC = 0;
    memset(data->tailleCFC, 0, sizeof(data->tailleCFC));
    nombreSommets = 0;
    nombreArcs = 0;
}

// Charger le graphe à partir d'un fichier texte
int chargerGraphe(const char* fichier) {
    FILE *file = fopen(fichier, "r");
    if (!file) {
        printf("Erreur : Impossible d'ouvrir le fichier '%s'.\n", fichier);
        return 0;
    }

    char ligne[256];
    int isRelationsSection = 0;

    while (fgets(ligne, sizeof(ligne), file)) {
        if (ligne[0] == '\n' || ligne[0] == '#') continue; //ignorer espace ou comm

        if (strstr(ligne, "Relations") != NULL) { //strstr recherche la sous section relations
            // Passer à la section des relations
            isRelationsSection = 1;
            continue;
        }

        if (!isRelationsSection) {
            // Lecture des infos sur les sommets
            int id, niveauTrophique;
            char nom[50];
            double population, tauxCroissance;
            if (!isRelationsSection && sscanf(ligne, "%d, %49[^,], %d, %lf, %lf", &id, nom, &niveauTrophique, &population, &tauxCroissance) != 5) {
                printf("Erreur : Ligne mal formee dans la section des sommets : %s\n", ligne);
                continue;
            }
            {
                // Initialisation des sommets avec les valeurs lues
                sommets[nombreSommets].id = id;
                strcpy(sommets[nombreSommets].nom, nom); // Copie le nom du sommet
                sommets[nombreSommets].niveauTrophique = niveauTrophique;
                sommets[nombreSommets].population = population;
                sommets[nombreSommets].populationInitiale = population;  // Initialisation de la population initiale
                sommets[nombreSommets].tauxCroissance = tauxCroissance;
                sommets[nombreSommets].tauxCroissanceInitial = tauxCroissance; // Initialisation du taux de croissance initial
                sommets[nombreSommets].capaciteCharge = 2 * population; // Exemple de K initial
                nombreSommets++;
            }
        } else {
            int sommet1, sommet2;
            double coefficient; //lecture sur les relations (arcs)
            if (sscanf(ligne, "%d %d %lf", &sommet1, &sommet2, &coefficient) == 3) {
                {
                    arcs[nombreArcs].coefficient = coefficient; // coefficient proportion d'alimentation
                    arcs[nombreArcs].sommet1 = sommet1;
                    arcs[nombreArcs].sommet2 = sommet2;
                    adj[sommet1][sommet2] = 1; //ajout a la mat
                    adjTranspose[sommet2][sommet1] = 1;//ajout a la mat transpose
                    adjNonOriente[sommet1][sommet2] = 1;
                    adjNonOriente[sommet2][sommet1] = 1;
                    nombreArcs++;
                }
            }
        }
    }

    fclose(file);
    return 1;
}


// Fonction pour vérifier si un sommet existe
int sommetExiste(int sommetId) {
    for (int i = 0; i < nombreSommets; i++) {
        if (sommets[i].id == sommetId) {
            return 1; // 1 si trouve
        }
    }
    return 0; //sinon 0
}
//-------------------------------------------------------CONNEXITE----------------------------------

// Fonction DFS (exploration en profondeur)
// Cette fonction explore les sommets atteignables depuis un sommet donné
// Paramètre collectPile : si activé, collecte les sommets dans une pile à la fin de l'exploration.
void dfs(int sommet, int matrice[MAX_SOMMETS][MAX_SOMMETS], int collectPile) {
    visite[sommet] = 1;
    for (int i = 1; i <= nombreSommets; i++) {
        if (matrice[sommet][i] && !visite[i]) { // Explore les voisins non visités
            dfs(i, matrice, collectPile);
        }
    }
    if (collectPile) {
        pile[sommetPile++] = sommet; // Ajouter à la pile à la fin de l'exploration
    }
}

// Vérifier si le graphe est connexe (toutes les parties du graphe sont reliées)
int estConnexe() {
    memset(visite, 0, sizeof(visite));
    dfs(1, adjNonOriente, 0);
    for (int i = 1; i <= nombreSommets; i++) {
        if (!visite[i]) return 0; // Si un sommet n'est pas visité, le graphe n'est pas connexe
    }
    return 1; //si connexe
}

// Vérification de la connexité et effectue une exploration DFS pour chaque sommet non visite, en creant une nouvelle composante a chaque fois.
int trouverComposantes(CFCData *data) {
    memset(visite, 0, sizeof(visite));
    memset(data->composante, -1, sizeof(data->composante));
    int composanteId = 0;

    for (int i = 1; i <= nombreSommets; i++) {
        if (!visite[i]) {
            dfs(i, adjNonOriente, 0);
            for (int j = 1; j <= nombreSommets; j++) {
                if (visite[j] && data->composante[j] == -1) {
                    data->composante[j] = composanteId;
                }
            }
            composanteId++;
        }
    }

    return composanteId; // Retourne le nombre de composantes connexes
}

//Reinitialise les variables utilisees pour gerer les composantes connexes.
// Vide la liste des composantes, remet les tailles a zero et reinitialise les sommets visites.
//reinit les numeros aussi des sommets
void reiniCompo(int composanteChoisie,CFCData *data) {
    int nouvelleMatrice[MAX_SOMMETS][MAX_SOMMETS] = {0};
    int nouveauxSommets[MAX_SOMMETS];
    int compteur = 0;

    // Filtrer les sommets de la composante choisie et les ajouter à nouveauxSommets
    for (int i = 1; i <= nombreSommets; i++) {
        if (data->composante[i] == composanteChoisie) {
            nouveauxSommets[compteur++] = i; // Ajout du sommet au tableau
        }
    }

    // Construire la matrice pour les sommets sélectionnés
    for (int i = 0; i < compteur; i++) {
        for (int j = 0; j < compteur; j++) {
            // Utiliser les indices originaux pour remplir la nouvelle matrice
            nouvelleMatrice[i][j] = adjNonOriente[nouveauxSommets[i]][nouveauxSommets[j]];
        }
    }

    // Mise à jour du graphe global
    memset(adjNonOriente, 0, sizeof(adjNonOriente));
    for (int i = 0; i < compteur; i++) {
        for (int j = 0; j < compteur; j++) {
            // Remplir la matrice globale avec les nouvelles connexions
            adjNonOriente[nouveauxSommets[i]][nouveauxSommets[j]] = nouvelleMatrice[i][j];
        }
    }

    // Mettre à jour nombreSommets et afficher les sommets d'origine
    nombreSommets = compteur;
    printf("Graphe mis à jour pour la composante %d avec %d sommets.\n", composanteChoisie, compteur);
    printf("Les sommets dans la composante sont :\n");
    for (int i = 0; i < compteur; i++) {
        printf("Sommet %d\n", nouveauxSommets[i]); // Affichage des sommets originaux
    }
    //affiche les anciens numeros mais reinitialise le graphe avec des autres indices
}


// Fonction principale pour la gestion des composantes
void gererComposantes(CFCData *data) {
    int nombreComposantes = trouverComposantes(data);
    if (nombreComposantes == 1) {
        printf("Le graphe est connexe.\n");
    } else {
        printf("Le graphe n'est pas connexe. Nombre de composantes : %d\n", nombreComposantes);
        for (int i = 0; i < nombreComposantes; i++) {
            printf("Composante %d : ", i);
            for (int j = 1; j <= nombreSommets; j++) {
                if (data->composante[j] == i) { // Liste des sommets appartenant a cette composante.
                    printf("%d ", j);
                }
            }
            printf("\n");
        }
        int choix;
        do {
            printf("Choisissez une composante à étudier (0 à %d) : ", nombreComposantes - 1);
            scanf("%d", &choix);
        } while (choix < 0 || choix >= nombreComposantes);

        if (choix >= 0 && choix < nombreComposantes) {
            reiniCompo(choix,data);
        } else {
            printf("Choix invalide.\n");
        }
    }
}

//---------------------------FORTE CONNEXITE---------------------------------------------------

// Explorer une CFC (Composante Fortement Connexe) en utilisant une exploration DFS.
// Cette fonction marque les sommets visités et les ajoute a une composante donnée (cfcId).
void explorerCFC(int sommet, int matrice[MAX_SOMMETS][MAX_SOMMETS], int cfcId, CFCData *data) {
    visite[sommet] = 1;
    data->cfc[cfcId][data->tailleCFC[cfcId]++] = sommet; // Ajout du sommet à la CFC
    printf("Sommet %d ajoute\n\n", sommet);//verif

    for (int i = 1; i <= nombreSommets; i++) {
        if (matrice[sommet][i] && !visite[i]) {
            // Appel recursif pour explorer les voisins non visites dans la matrice.
            explorerCFC(i, matrice, cfcId,data);
        }
    }
}

// Trouver toutes les CFC du graphe en utilisant l'algorithme de Kosaraju.
// L'algorithme s'appuie sur deux explorations DFS : une sur le graphe et l'autre sur son transpose.
// Le resultat est stocke dans la structure CFCData.
void trouverCFC(CFCData *data) {
    memset(visite, 0, sizeof(visite));
    sommetPile = 0; // Réinitialisation de la pile

    // Étape 1 : Collecter l'ordre de finition avec la matrice d'adjacence
    for (int i = 1; i <= nombreSommets; i++) {
        if (!visite[i]) {
            dfs(i, adj, 1); // DFS avec collecte dans la pile
        }
    }
    printf("====================================\n");
    printf("Ordre de finition des sommets (pile) : ");
    for (int i = sommetPile - 1; i >= 0; i--) {
        printf("%d ", pile[i]);
    }
    printf("\n");
    printf("====================================\n\n");

    // Étape 2 : Explorer les composantes sur le graphe transposé
    memset(visite, 0, sizeof(visite));
    data->nombreCFC = 0;

    while (sommetPile > 0) {
        int sommet = pile[--sommetPile]; // Récupérer le sommet de la pile
        if (!visite[sommet]) {
            printf("[ CFC %d ]\n", data->nombreCFC + 1);
            printf("Exploration depuis le sommet %d\n", sommet);
            explorerCFC(sommet, adjTranspose, data->nombreCFC++,data);
        }
    }
    printf("====================================\n");
    printf("Nombre total de CFC trouvees : %d\n", data->nombreCFC);
    printf("====================================\n");
}


// Déterminer si le graphe est fortement connexe, est fortement connexe si une seule CFC
int estFortementConnexe(CFCData *data) {
    trouverCFC(data);
    return data->nombreCFC == 1; // Fortement connexe si une seule CFC
}

// Conclusion sur la connexité
void analyserConnexite(CFCData*data) {
    if (estConnexe()) {
        printf("Le graphe est connexe.\n");
        if (estFortementConnexe(data)) {
            printf("De plus, il est fortement connexe.\n");
        } else {
            printf("Cependant, il n'est pas fortement connexe.\n");
        }
    } else {
        printf("Le graphe n'est pas connexe.\n");
        if (estFortementConnexe(data)) {
            printf("Mais, il est fortement connexe.\n");
        } else {
            printf("Et, il n'est pas fortement connexe.\n");
        }
    }
}

//----------------------------------------------------------------Calcul de la complexite du reseau -------------------------------------------
// Calculer la hauteur trophique (niveau maximum)
int calculerHauteurTrophique() {
    int maxNiveau = 0;
    for (int i = 0; i < nombreSommets; i++) {
        if (sommets[i].niveauTrophique > maxNiveau) {
            maxNiveau = sommets[i].niveauTrophique;
        }
    }
    return maxNiveau;
}

// Calculer la densité de liaison
double calculerDensiteLiaison() {
    if (nombreSommets <= 1) {
        return 0.0; // Retourne 0 pour eviter une division par zero si un seul sommet.

    }
    return (double)nombreArcs / (nombreSommets * (nombreSommets - 1));
}

// Calculer la variance des degrés
double calculerVarianceDegre() {
    int degres[MAX_SOMMETS] = {0};  // Tableau pour stocker les degrés des sommets
    double somme = 0.0, sommeCarres = 0.0;

    // Calculer les degrés pour chaque sommet
    for (int i = 0; i < nombreArcs; i++) {
        degres[arcs[i].sommet1 - 1]++;  // Degré sortant
        degres[arcs[i].sommet2 - 1]++;  // Degré entrant
    }

    // Calculer la somme et la somme des carrés
    for (int i = 0; i < nombreSommets; i++) {
        somme += degres[i];
        sommeCarres += degres[i] * degres[i];
    }

    // Calcul de la variance : (somme des carres / N) - (moyenne au carre)
    double moyenne = somme / nombreSommets;
    return (sommeCarres / nombreSommets) - (moyenne * moyenne);
}



//---------------------------------------------------------------AFFICHAGE DES FONCTIONS--------------------------------------------------------
void afficherNombreSommets() {
    printf("\nNombre de sommets: %d \n", nombreSommets);
}


void afficherSommets() {
    printf("%-5s %-15s %-12s %-20s\n", "ID", "Nom", "Population", "Taux de croissance");
    printf("------------------------------------------------------\n");
    for (int i = 0; i < nombreSommets; i++) {
        printf(
                "%-5d %-15s %-12d %-15.2f\n",
                sommets[i].id,                // ID du sommet
                sommets[i].nom,               // Nom du sommet
                sommets[i].population,        // Population (valeur entiere, mais stockee en double)
                sommets[i].tauxCroissance    // Capacite de charge
        );
    }
}

void afficherArcs() {
    printf("%-5s %-15s %-15s %-15s %-15s\n", "ID1", "Predateur", "ID2", "Proie", "Coefficient Alimentaire");
    printf("------------------------------------------------------------------------------\n");
    for (int i = 0; i < nombreArcs; i++) {
        printf(
                "%-5d %-15s %-15d %-15s %-15.2f\n",
                arcs[i].sommet1,                          // ID du sommet1
                sommets[arcs[i].sommet1 - 1].nom,         // Nom du sommet1
                arcs[i].sommet2,                          // ID du sommet2
                sommets[arcs[i].sommet2 - 1].nom,
                arcs[i].coefficient);


    }
    printf("\nNombre d'arcs : %d\n", nombreArcs);
}



// Fonction pour afficher les successeurs d'un sommet
void afficherSuccesseurs(int sommetid) {
    printf("\nSuccesseurs du sommet %d (%s):\n", sommetid, sommets[sommetid-1].nom);
    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet2 == sommetid) {
            printf("%d -> %d (%s)\n", sommetid, arcs[i].sommet1, sommets[arcs[i].sommet1 - 1].nom);
        }
    }
}

// Fonction pour afficher les successeurs d'un sommet
void afficherPredecesseurs(int sommetid) {
    printf("\nPredecesseurs du sommet %d (%s):\n", sommetid, sommets[sommetid-1].nom);
    for (int i = 0; i < nombreArcs; i++) {
        if (arcs[i].sommet1 == sommetid) {
            printf("%d -> %d (%s)\n", sommetid, arcs[i].sommet2, sommets[arcs[i].sommet2 - 1].nom);
        }
    }
}

// Afficher les critères de complexité
void afficherComplexite() {
    printf("\nCriteres de complexite du reseau :\n");
    printf("1. Nombre d'especes : %d\n", nombreSommets);
    printf("2. Hauteur trophique : %d\n", calculerHauteurTrophique());
    printf("3. Densite de liaison : %.4f\n", calculerDensiteLiaison());
    printf("4. Variance des degres : %.4f\n", calculerVarianceDegre());
}